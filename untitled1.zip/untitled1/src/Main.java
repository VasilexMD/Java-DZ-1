//Шаг 1: Создать и декларировать все примитивные типы как глобальные и локальные переменные
public class Main {
    // Глобальные переменные
    static byte globalByte;
    static short globalShort;
    static int globalInt;
    static long globalLong;
    static float globalFloat;
    static double globalDouble;
    static boolean globalBoolean;
    static char globalChar;

    public static void main(String[] args) {
        // Локальные переменные
        byte localByte;
        short localShort;
        int localInt;
        long localLong;
        float localFloat;
        double localDouble;
        boolean localBoolean;
        char localChar;
    }
}

//Шаг 2: Считать из консоли каждый примитивный тип и присвоить его переменной

import java.util.Scanner;

public class Main {
    // ... (Глобальные переменные)

    public static void main(String[] args) {
        // ... (Локальные переменные)

        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите значение для byte:");
        localByte = scanner.nextByte();

        System.out.println("Введите значение для short:");
        localShort = scanner.nextShort();

        System.out.println("Введите значение для int:");
        localInt = scanner.nextInt();

        System.out.println("Введите значение для long:");
        localLong = scanner.nextLong();

        System.out.println("Введите значение для float:");
        localFloat = scanner.nextFloat();

        System.out.println("Введите значение для double:");
        localDouble = scanner.nextDouble();

        System.out.println("Введите значение для boolean:");
        localBoolean = scanner.nextBoolean();

        System.out.println("Введите значение для char:");
        localChar = scanner.next().charAt(0);
    }
}

//Шаг 3: Вывести все типы в таблицу при помощи println() и printf()

public class Main {
    // ... (Глобальные переменные и импорты)

    public static void main(String[] args) {
        // ... (Локальные переменные и считывание значений)

        // Вывод значений с использованием println()
        System.out.println("Тип данных | Глобальные переменные | Локальные переменные");
        System.out.println("byte       | " + globalByte + "                  | " + localByte);
        System.out.println("short      | " + globalShort + "                  | " + localShort);
        System.out.println("int        | " + globalInt + "                  | " + localInt);
        System.out.println("long       | " + globalLong + "                  | " + localLong);
        System.out.println("float      | " + globalFloat + "                  | " + localFloat);
        System.out.println("double     | " + globalDouble + "                  | " + localDouble);
        System.out.println("boolean    | " + globalBoolean + "                  | " + localBoolean);
        System.out.println("char       | " + globalChar + "                  | " + localChar);

        // Вывод значений с использованием printf()
        System.out.printf("%-10s | %-20s | %-
